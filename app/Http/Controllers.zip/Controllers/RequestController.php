<?php

namespace App\Http\Controllers;

use App\Mail\SendResponseMail;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use App\MdRequestManage;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use App\Jobs\QueueMailSend;

class RequestController extends CommonController
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * lấy danh sách user
     *
     * @return void
     */
    public function getUserList(Request $request){
        $ma_phong_ban = $request->input('ma_phong_ban');
        $user = User::where('ma_phong_ban', $ma_phong_ban)->orderBy('name')->get();

        return response($user->toJson(), 200)->header('Content-Type', 'application/json');
    }

    /**
     * Danh sách các yêu cầu mới
     *
     * @return void
     */
    public function RequestManagement()
    {
        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();
        $assignedPerson = User::whereIn('role', [1])->get();

        $dsYeuCau = MdRequestManage::with(['phong_ban','user'])->where('trang_thai', 0)->orderBy('ngay_tao', 'desc')->get();
        $contentData = array(
            'dsYeuCau' => $dsYeuCau,
            'assignedPerson' => $assignedPerson,
            'masterData' => array(
                'activeMenu' => 3,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            )
        );
        return view('requestManage', $contentData);
    }

    /**
     * Danh sách các yêu cầu mới
     *
     * @return void
     */
    public function RequestPendingManagement()
    {
        $userID = Auth::user()->username;

        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();

        $assignedPerson = User::whereIn('role', [1])->get();

        $dsYeuCau = MdRequestManage::with(['phong_ban','user', 'xu_ly'])->whereIn('trang_thai', [1,2])->orderBy('trang_thai', 'asc')->orderBy('han_xu_ly', 'asc')->get();
        $contentData = array(
            'dsYeuCau' => $dsYeuCau,
            'assignedPerson' => $assignedPerson,
            'masterData' => array(
                'activeMenu' => 4,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            )
        );
        return view('requestPendingManage', $contentData);
    }

    /**
     * Danh sách các yêu cầu mới
     *
     * @return void
     */
    public function RequestCompleteManagement()
    {
        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();

        $assignedPerson = User::whereIn('role', [1])->get();

        $dsYeuCau = MdRequestManage::with(['phong_ban','user', 'xu_ly'])->whereIn('trang_thai', [3,4])->orderBy('trang_thai', 'asc')->orderBy('ngay_xu_ly', 'desc')->get();
        $contentData = array(
            'dsYeuCau' => $dsYeuCau,
            'assignedPerson' => $assignedPerson,
            'masterData' => array(
                'activeMenu' => 5,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            )
        );
        return view('requestCompleteManage', $contentData);
    }

    /**
     * Lấy thông tin chi tiết yêu cầu
     *
     * @return void
     */
    public function getRequest(Request $request){
        $ma_yeu_cau = $request->ma_yeu_cau;
        $yeuCau = '';
        if (isset($ma_yeu_cau)){
            $yeuCau = MdRequestManage::with(['phong_ban','user','xu_ly'])->find($ma_yeu_cau);
        }

        return response($yeuCau->toJson(), 200)->header('Content-Type', 'application/json');
    }

    /**
     * Lấy thông tin chi tiết yêu cầu dùng cho link tử email
     *
     * @return void
     */
    public function requestAssign($ma_yeu_cau){
        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();

        $request = MdRequestManage::with('phong_ban')->where('ma_yeu_cau', $ma_yeu_cau)->orderBy('ngay_tao', 'desc')->get();
        $assignedPerson = User::whereIn('role', [1])->get();
        $contentData = array(
            'request' => $request,
            'assignedPerson' => $assignedPerson,
            'masterData' => array(
                'activeMenu' => 3,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            ),
        );

        return view('requestAssign', $contentData);
    }

    public function requestAssignSet(Request $request){
        $userId = Auth::user()->username;
        $ma_yeu_cau = $request->input('ma_yeu_cau');
        $nguoi_xu_ly = $request->input('nguoi_xu_ly');
        $trang_thai = $request->input('trang_thai');
        $han_xu_ly = $request->input('han_xu_ly');
        $loai_yeu_cau = $request->input('loai_yeu_cau');
        $yeu_cau_xu_ly = $request->input('yeu_cau_xu_ly');

//        $timestamp = strtotime($han_xu_ly);
//        if ($timestamp === FALSE) {
//            $timestamp = strtotime(str_replace('/', '-', $han_xu_ly));
//        }
        $timestamp = strtotime(str_replace('/', '-', $han_xu_ly));
        $date = date('Y-m-d',$timestamp);

        $updateReq = MdRequestManage::find($ma_yeu_cau);
        if ($updateReq->trang_thai == 3 || $updateReq->trang_thai == 4){
            return redirect()->route('assignRequest',[$ma_yeu_cau])->with('error', 'Yêu cầu đã được xử lý, không thể cập nhật.');
        }else{
            try{
                //admin xử lý luôn yêu cầu
                if ($trang_thai == 3 || $trang_thai == 4){
                    $updateReq->trang_thai = $trang_thai;
                    $updateReq->nguoi_xu_ly = $userId;
                    $updateReq->ngay_xu_ly = Carbon::now();
                    $updateReq->thong_tin_xu_ly = $yeu_cau_xu_ly;
                    $updateReq->loai_yeu_cau = $loai_yeu_cau;
                    $updateReq->save();
                }else{
                    //assign cho nhân viên xử lý
                    $updateReq->trang_thai = 1;
                    $updateReq->nguoi_xu_ly = $nguoi_xu_ly;
                    if (isset($han_xu_ly)){
                        $updateReq->han_xu_ly = $date;
                    }
                    $updateReq->loai_yeu_cau = $loai_yeu_cau;
                    $updateReq->yeu_cau_xu_ly = $yeu_cau_xu_ly;
                    $updateReq->save();
                }
                try{
                    $assignData = User::where('username', $nguoi_xu_ly)->get();
                    $yeuCau = MdRequestManage::find($ma_yeu_cau);
                    $data = array(
                        'ma_yeu_cau' => $ma_yeu_cau,
                        'nguoi_gui'     => $yeuCau->ho_ten,
                        'phong_ban'     => $yeuCau->phong_ban,
                        'tieu_de'         => $yeuCau->tieu_de,
                        'noi_dung'       => $yeuCau->noi_dung,
                        'nguoi_xu_ly'   => $yeuCau->nguoi_xu_ly,
                        'yeu_cau_xu_ly' => $yeuCau->yeu_cau_xu_ly,
                        'thong_tin_xu_ly' => $yeuCau->thong_tin_xu_ly,
                        'trang_thai' =>$yeuCau->trang_thai,
                    );
                    //mail to assign person
                    $email = '';
                    foreach ($assignData as $as){
                        $email = $as->email;
                    }
                    if (isset($email)){
                        dispatch(new QueueMailSend(2, $email, $data));
                    }

                    //mail to requester
                    $reqUser = User::where('username', $updateReq->user_yeu_cau)->get();
                    $receiptEmail = null;
                    foreach ($reqUser as $req){
                        $receiptEmail = $req->email;
                    }
                    if (isset($receiptEmail)){
                        dispatch(new QueueMailSend(3, $receiptEmail, $data));
                    }

                    return response(['info' => 'success', 'Content' => 'Cập nhật thành công.'], 200)->header('Content-Type', 'application/json');
                }catch (\Exception $exception){
                    return response(['info' => 'success', 'Content' => 'Cập nhật thành công.'], 200)->header('Content-Type', 'application/json');
                }
            }catch (\Exception $exception){
                return response(['info' => 'fail', 'Content' => 'Cập nhật thất bại, vui lòng thử lại.'], 200)->header('Content-Type', 'application/json');
            }
        }


    }

    /**
     * Lấy danh sách những yêu cầu được giao
     *
     * @return void
     */
    public function requestHandle(){
        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();

        $dsRequest = MdRequestManage::with(['phong_ban','user'])->where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->orderBy('trang_thai', 'desc')->orderBy('han_xu_ly', 'asc')->get();

        $contentData = array(
            'dsRequest' => $dsRequest,
            'masterData' => array(
                'activeMenu' => 6,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            )
        );
        return view('requestHandle', $contentData);
    }

    /**
     * Lấy danh sách những yêu cầu được giao đã hoàn thành
     *
     * @return void
     */
    public function requestHandleComplete(){
        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();

        $assignedPerson = User::whereIn('role', [1])->get();

        $dsRequest = MdRequestManage::with(['phong_ban','user'])->where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->orderBy('ngay_xu_ly', 'desc')->get();

        $contentData = array(
            'dsRequest' => $dsRequest,
            'assignedPerson' => $assignedPerson,
            'masterData' => array(
                'activeMenu' => 7,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            )
        );
        return view('requestHandleComplete', $contentData);
    }

    public function requestUpdate($ma_yeu_cau){
        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();

        $request = MdRequestManage::with(['phong_ban','user'])->where('ma_yeu_cau', $ma_yeu_cau)->orderBy('ngay_tao', 'desc')->get();
        foreach ( $request as $key=>$val){
            if ($val->trang_thai == 3 || $val->trang_thai == 4){
                return redirect('request-handle')->with('alert', 'Yêu cầu này đã được xử lý.');
            }
        }
        $contentData = array(
            'request' => $request,
            'masterData' => array(
                'activeMenu' => 6,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            ),
        );

        return view('requestUpdate', $contentData);
    }

    public function requestUpdateStatus(Request $request){
        $ma_yeu_cau = $request->input('ma_yeu_cau');
        $trang_thai = $request->input('trang_thai');
        $thong_tin_xu_ly = $request->input('thong_tin_xu_ly');

        $updateReq = MdRequestManage::find($ma_yeu_cau);
        $reqUser = User::where('username', $updateReq->user_yeu_cau)->get();
        $receiptEmail = null;
        foreach ($reqUser as $req){
            $receiptEmail = $req->email;
        }

        if ($updateReq->trang_thai == 3 || $updateReq->trang_thai == 4){
            return response(['info' => 'Fail', 'Content' => 'Yêu cầu đã được xử lý, không thể cập nhật.'], 200)->header('Content-Type', 'application/json');
//            return redirect()->route('requestUpdate', [$ma_yeu_cau])->with('error', 'Yêu cầu đã được xử lý, không thể cập nhật.');
        }else {
            try {
                $updateReq->trang_thai = $trang_thai == 1 ? 2 : $trang_thai;
                $updateReq->ngay_xu_ly = Carbon::now();
                $updateReq->thong_tin_xu_ly = $thong_tin_xu_ly;
                $updateReq->save();
                try {
                    $data = array(
                        'ma_yeu_cau' => $ma_yeu_cau,
                        'tieu_de' => $updateReq->tieu_de,
                        'noi_dung' => $updateReq->noi_dung,
                        'thong_tin_xu_ly' => $updateReq->thong_tin_xu_ly,
                        'trang_thai' => ($updateReq->trang_thai == 3 ? 'Hoàn thành' : ($updateReq->trang_thai == 4 ? "Từ chối" : "")),
                    );
                    if ( $trang_thai == 1) {
                        if (isset($receiptEmail)) {
                            dispatch(new QueueMailSend(4, $receiptEmail, $data));
                        }

                        $managerUser = User::where('role', 2)->get();
                        $receiptList = array();
                        foreach ($managerUser as $user) {
                            array_push($receiptList, $user->email);
                        }

                        dispatch(new QueueMailSend(4, $receiptList, $data));
                    }

                    return response(['info' => 'Success', 'Content' => 'Cập nhật thành công.'], 200)->header('Content-Type', 'application/json');
                } catch (\Exception $exception) {
                    return response(['info' => 'Success', 'Content' => 'Cập nhật thành công.'], 200)->header('Content-Type', 'application/json');
                }
            } catch (\Exception $exception) {
                return response(['info' => 'Fail', 'Content' => 'Cập nhật thất bại, vui lòng thử lại.'], 200)->header('Content-Type', 'application/json');
            }
        }
    }

    public function myRequest(){
        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();

        $dsYeuCau = MdRequestManage::with(['phong_ban','user'])->where('user_yeu_cau', $userID)->orderBy('trang_thai', 'asc')->orderBy('ngay_tao', 'desc')->get();
        $contentData = array(
            'dsYeuCau' => $dsYeuCau,
            'masterData' => array(
                'activeMenu' => 8,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            )
        );
        return view('myRequest', $contentData);
    }

    public function myRequestDetail($ma_yeu_cau){
        $userID = Auth::user()->username;

        $totalNewRequest = MdRequestManage::whereIn('trang_thai', [0])->count();
        $pendingRequest = MdRequestManage::whereIn('trang_thai', [1,2])->count();
        $totalAssignRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [1,2])->count();
        $totalMyRequest = MdRequestManage::where('user_yeu_cau', $userID)->whereIn('trang_thai', [0,1])->count();
        $totalMyCompleteRequest = MdRequestManage::where('nguoi_xu_ly', $userID)->whereIn('trang_thai', [3,4])->count();
        $totalCompleteRequest = MdRequestManage::whereIn('trang_thai', [3,4])->count();

        $request = MdRequestManage::with('phong_ban')->where('ma_yeu_cau', $ma_yeu_cau)->orderBy('ngay_tao', 'desc')->get();
        $contentData = array(
            'request' => $request,
            'masterData' => array(
                'activeMenu' => 8,
                'totalNewRequest' => $totalNewRequest,
                'totalAssignRequest' => $totalAssignRequest,
                'pendingRequest' => $pendingRequest,
                'totalMyRequest' => $totalMyRequest,
                'totalMyCompleteRequest' => $totalMyCompleteRequest,
                'totalCompleteRequest' => $totalCompleteRequest,
            ),
        );

        return view('myRequestDetail', $contentData);
    }
}
